# Dashboard Royale — opening instructions

Open dashboard_royale.html in Chrome, Edge or Firefox with JavaScript enabled. No server, account or installation is required. The data is embedded. Internet is optional for fonts.

Start with SUBMISSION_CHECKLIST.md for the team’s remaining steps. WRITEUP.md is the main narrative; CLAIMS_AND_EVIDENCE.md is the separate appendix and AI disclosure; VIDEO_SCRIPT.md is the recording script.

The code directory contains all transformation and dashboard source files plus the generated aggregate data. Rebuild instructions are in the checklist. claims_check_output.txt contains the independent rerun on the organizer data.

QA: rebuilt from organizer commit 5f9274bdc3efa6614e6c081becaeadda34c57a32; confirmed forecast MAE; tested period, bank, zone, guest region/tier and reset interactions in headless Chrome without JavaScript errors; checked 390px mobile width for horizontal page overflow; reviewed desktop screenshot. This does not guarantee a judging score or establish causal effects. Machine filters now preserve dated placements, including all four machines that changed banks.

Nothing has been published or submitted. The team must record its video, review the materials, and submit accessible files/links on Devpost.

## Interactive 3D scene

The entrance now integrates the reel geometry and symbol texture from Virtual Slot Machine by Kevin Ellis (2015), under MIT. Source: https://github.com/YorkshireKev/virtual-slot-machine . The bundled legacy Three.js renderer and upstream licenses are in code/vendor; licenses are also embedded in the standalone HTML. Original source is retained for provenance. code/casino.js implements the adapted scene, spin animation, cabinet, casino room and accessible controls.

Drag the red lever downward at least 65 pixels and release to spin. A shorter pull cancels. Touch uses the same gesture. Focus the lever and press Enter/Space/ArrowDown, or use Spin reels. Camera movement can be paused; system reduced-motion settings suppress animated spins. Spins are decorative and do not alter or simulate the analytical data. The HTML remains self-contained and opens locally. WebGL is required for the entrance only; the analytical dashboard remains available if WebGL is unavailable.

## Rebuild and validate the backend

From this folder, with Python and the organizer dataset downloaded:

```sh
python -m pip install -r code/requirements.txt
python code/build_data.py /path/to/dashboard-royale/data code/data.json
python code/validate_backend.py /path/to/dashboard-royale/data > backend_validation.json
python code/analysis.py /path/to/dashboard-royale/data > claims_check_output.txt
python code/validate_advanced.py /path/to/dashboard-royale/data > advanced_validation.json
python code/build_page.py
```

No server is required: computation runs once in DuckDB, and the dashboard reads only aggregated embedded JSON. Source money and exposure retain precision until display. Backend checks fail on duplicate join keys, invalid availability, missing game math, or broken monetary reconciliation. See JUDGE_REVIEW.md for the current rubric assessment.


## Final strengthened review

The recommended July commitment is one $1,200 inspection, with $98,800 preserved. The $7,500 signage and $4,000 pilot are fully priced but deferred. The three-action comparison remains available to explain this decision. Advanced methods/results: code/advanced_analysis.py and advanced_results.json. Pilot details: PILOT_PROTOCOL.md. Prior-year project research: PAST_PROJECT_RESEARCH.md. Final assessment: JUDGE_REVIEW.md.

QA includes every valid period/zone/bank combination (2,304 views), 420 guest views, empty cohorts, ranking and value reconciliation, scope labels, evidence links, sliders, expandable detail, keyboard and drag spins, and mobile overflow. browser_validation.json records the browser checks. The original casino.js and both image assets were byte-for-byte unchanged versus the preceding package; design_preservation.json records that comparison.

For browser regression tests, install Playwright in your own development environment and load dashboard_royale.html in a Playwright page. Call `await require('./code/browser_checks.cjs')(page)`. No Playwright dependency is required to open the dashboard. The test assumes Chromium with WebGL support for the optional casino interaction checks.
