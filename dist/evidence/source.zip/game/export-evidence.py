"""Export the exact dashboard payload; run after rebuilding dashboard.html."""
import json, re, pathlib, hashlib
root = pathlib.Path(__file__).resolve().parent
page = (root/'dist/dashboard.html').read_text(encoding='utf-8')
match = re.search(r'<script[^>]*id=[\"\']data[\"\'][^>]*>(.*?)</script>', page, re.S)
if not match:
    raise SystemExit('Dashboard data element missing')
data = json.loads(match.group(1))
out = 'window.ACE_EVIDENCE='+json.dumps(data,separators=(',',':'),allow_nan=False)+';\n'
(root/'dist/evidence-data.js').write_text(out,encoding='utf-8')
print('Exported identical dashboard evidence:',len(data['machines']),'machines;',len(out),'bytes')
protected=['assets/casino.js','assets/scene-data.js','assets/gilded-cabinet-refined.png','assets/vegas-poker-lounge.png','entrance.css']
manifest={p:hashlib.sha256((root/'dist'/p).read_bytes()).hexdigest() for p in protected}
path=root/'design-lock.json'
if not path.exists():path.write_text(json.dumps(manifest,indent=2))
else:assert json.loads(path.read_text())==manifest,'Protected casino design changed'
