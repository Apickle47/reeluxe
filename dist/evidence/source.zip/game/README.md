# Reeluxe

A casino management game set at **The Gilded Ace**, with Ace, a Gemini-powered host.

# The Gilded Ace: Floor Manager

A public casino-manager simulator alongside an audited Dashboard Royale judge workspace. The original cinematic machine and casino backdrop are unchanged. The simulator is an original fictional economy; its cash, guests, prices and outcomes are not estimates from the challenge data.

## Player role and route

You are the **casino manager**, not a gambling customer. Start with three machines and $2,400. Pick a drink menu, crew and advertising, open for a short animated night, help guests or machines during the rush, and reinvest the result. Buy, repair, upgrade and move machines between three areas. Seven recurring events shift demand. Milestones reward growth. At $20,000, optionally open another resort with a permanent earnings bonus. There is no final night, timer while away or real money.

`#game` opens the simulator. `#analysis` opens the historical decision workspace. `dashboard.html` retains the complete analysis and actual $100,000 challenge plan. The original investigation remains available in the judge route, with a separate save.

Gemini is live on the existing Sites host using gemini-3.5-flash-lite and a server-side secret from the Gilded Ace free-tier project. Billing was not enabled. No separate Cloudflare account is required. Local guidance handles quota or capacity failures. Live tests verified gameplay, historical evidence and calculator use; this is not an exhaustive accuracy guarantee.

## Run and test

Serve `dist` with any static HTTP server. No build step or API key is required.

- `python export-evidence.py`: export the exact JSON payload embedded in `dist/dashboard.html` to `dist/evidence-data.js`, checking protected casino assets.
- `node test-evidence.cjs`: 21 parity, arithmetic, filter and design-preservation checks.
- `node test-game.cjs`: 35 budget, target, conflict, score and save-state checks.
- `python package-evidence.py`: package publicly downloadable source and check static local links. Requires the adjacent `dashboard_royale` analysis directory in the development checkout.

The game and dashboard use the identical computed source payload. `evidence-engine.js` owns the game's filtered aggregations and scenario calculations. The 100-point learning score is explicitly separate from judging and financial outcomes. For raw-data reproduction, use the analysis folder's builders and validation scripts with the organizer's data download and the supplied Python requirements.

## Open-source credits

- [2048 by Gabriele Cirulli](https://github.com/gabrielecirulli/2048), MIT: adapted local-storage component with project-specific keys; safe memory fallback, saved progress and personal best. License in `dist/vendor/2048-LICENSE.txt`.
- [Virtual Slot Machine by Kevin Ellis](https://github.com/YorkshireKev/virtual-slot-machine), MIT: existing adapted animated reels and textures. License included in vendor.
- Three.js, MIT: existing 3D renderer; license included in vendor.
- [Unciv](https://github.com/yairm210/Unciv): design inspiration for turns and readable resource tradeoffs. No code or assets copied.
- Original game logic and interface are AI-assisted. Cabinet and background are AI-generated; all people/casino are fictional.

## Present in two minutes

Spend 20 seconds showing a night, one upgrade and Ace's comparison. Then open Judge workspace: the bottom-ten decision, moved-machine comparison, downtime/switching, original May–June holdout and priced plan. Explain clearly that the playable economy is fictional and the judge workspace is the reproducible challenge analysis. The game does not replace the required analytics.

Run `node test-sim.cjs` (19 checks), `node test-host.mjs` (9 mocked adapter checks), `node test-game.cjs` (35), `node test-evidence.cjs` (21) and `node test-decision.cjs` (7). The simulator suite includes 200 allocation seeds and a 500-night run. Backend sources contain no credentials.

## Verification and handoff

See `dist/evidence/QA_REPORT.md` for actual completed tests and remaining limits. The original analysis was independently rechecked against the organizer parquet: 11,045 backend checks and 100 advanced study checks passed. New game checks cover catalogue conflicts, reserve/repair limits, source parity, dated placements, guest filters, scenario reconciliation and protected visual assets.

The team must record the <=2-minute demo, review the <=400-word write-up and AI disclosure, add attribution, confirm access on an independent device, and submit on Devpost. Domain purchase/connection and separate GoDaddy-track eligibility remain team actions. No domain purchase or competition submission has been performed.

## Two clear paths

Primary navigation is now **Play Casino Manager** and **Our Casino Findings**. The former is optional fictional practice; the latter is the challenge submission, presented as our decision, why, and check our work. The findings overview links directly into date/bank/guest filters, mover studies, downtime, costs and validation. Quiz rounds and the old tour are not part of this navigation. Existing plan saves and underlying analytical calculations remain intact; custom what-if plans are explicitly separated from our funded recommendation.

Ace is an original SVG casino-worker illustration with suit, tie, glasses and badge. “Try before spending” compares the selected machine with keeping cash, showing upfront costs separately from one-night net results. Browser and server share `ace-advisor.js`; advice never makes purchases. The live Gemini backend is connected on Sites. Seven new advisor checks bring the current automated suite to 98 passing checks.

Adaptive help: Ace offers Keep it simple / Show numbers and read-only guidance based on cash, wear and recent results. Optional reviewed findings answers include limitations and next checks. Live Gemini is connected; see the recorded evaluation and its limits. Presentation: dist/evidence/VIDEO_SCRIPT.md.

Ace's Two Futures: select a machine and click Repair or buy? Read-only comparisons include keep cash, repair, and a new machine. Choosing a card explicitly spends fictional cash. Setup: dist/evidence/GEMINI_SETUP.md; prepared Cloudflare config: server/wrangler.jsonc. Live acceptance: server/check-live.mjs.


Current review: dist/evidence/JUDGE_REVIEW.md. Gemini evidence-agent tests: node test-evidence-agent.mjs. Current hosting: node build-host.mjs followed by bundling server/site-worker.mjs to dist/server/index.js; runtime secrets are configured in Sites, never the client. See dist/evidence/GEMINI_SETUP.md.


## Ace’s rehearsal

One click asks Gemini to propose feasible changes, test 24 alternative nights per idea and select a supported recommendation. Calculator facts render the explanation; no unsupported free-form financial claims are used in this mode. Game state changes only on explicit selection. Run `node test-rehearsal.mjs` for 28 checks, including 150 independent scenario reconciliations. Current total: 155 checks. See dist/evidence/GEMINI_ENTRY.md and GEMINI_EVALUATION_REVIEW.md.
