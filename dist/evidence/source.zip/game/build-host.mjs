import {mkdirSync,readdirSync,cpSync,writeFileSync} from 'node:fs';
mkdirSync('dist/client',{recursive:true});
for(const item of readdirSync('dist',{withFileTypes:true}))if(!['client','server','.openai'].includes(item.name))cpSync('dist/'+item.name,'dist/client/'+item.name,{recursive:true});
mkdirSync('dist/server',{recursive:true});
writeFileSync('dist/server/wrangler.json',JSON.stringify({name:'gilded-ace',main:'index.js',compatibility_date:'2026-11-08',assets:{directory:'../client',binding:'ASSETS',run_worker_first:['/api/*']}}));
